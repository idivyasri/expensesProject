export interface UserData{
    // id:string,
    name:string,
    username:string,
    gmail:string,
    password:string,
}